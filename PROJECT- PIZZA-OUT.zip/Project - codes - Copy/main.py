#main

import tkinter as tk
from tkinter import messagebox
from order import open_order_window  # Importing the function to open the order summary window

def main_window():
    # Create the main window
    root = tk.Tk()
    root.title("Piz-Out Ordering System")
    root.geometry("400x350")  # Window size

    # Label for pizza selection
    pizza_label = tk.Label(root, text="Select Pizza")
    pizza_label.pack(pady=10)

    # Pizza options
    pizza_options = ["Margherita", "Pepperoni", "BBQ Chicken", "Veggie", "Hawaiian"]
    pizza_var = tk.StringVar(root)
    pizza_var.set(pizza_options[0])  # Default pizza
    pizza_menu = tk.OptionMenu(root, pizza_var, *pizza_options)
    pizza_menu.pack(pady=5)

    # Label for drink selection
    drink_label = tk.Label(root, text="Select Drink")
    drink_label.pack(pady=10)

    # Drink options
    drink_options = ["Coke", "Pepsi", "Sprite", "Water"]
    drink_var = tk.StringVar(root)
    drink_var.set(drink_options[0])  # Default drink
    drink_menu = tk.OptionMenu(root, drink_var, *drink_options)
    drink_menu.pack(pady=5)

    # Label for quantity input
    quantity_label = tk.Label(root, text="Enter Quantity")
    quantity_label.pack(pady=10)
    quantity_entry = tk.Entry(root)
    quantity_entry.pack(pady=5)

    # Function to handle order placement
    def place_order():
        pizza = pizza_var.get()
        drink = drink_var.get()
        quantity = quantity_entry.get()

        # Check if quantity is valid (greater than 0 and a number)
        if not quantity.isdigit() or int(quantity) < 1:
            messagebox.showerror("Invalid Input", "Please enter a valid quantity (1 or more).")
            return

        # Open the order summary window
        open_order_window(root, pizza, drink, quantity)

    # Place Order button
    order_button = tk.Button(root, text="Place Order", command=place_order)
    order_button.pack(pady=10)

    # Exit button
    exit_button = tk.Button(root, text="Exit", command=root.quit)
    exit_button.pack(pady=5)

    root.mainloop()  # Run the main window loop

if __name__ == "__main__":
    main_window()  # Call the main window function
