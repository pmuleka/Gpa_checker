### main.py
# Entry point for the Piz-Out Ordering System
import tkinter as tk
from order import Order
from menu import pizza_sizes, toppings, drinks
from images import pizza_image, drink_image

class PizzaOrderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Piz-Out Ordering System")
        
        self.order = Order()
        
        # Labels
        tk.Label(root, text="Select Pizza Size").pack()
        self.size_var = tk.StringVar()
        for size in pizza_sizes:
            tk.Radiobutton(root, text=size, variable=self.size_var, value=size).pack()
        
        tk.Label(root, text="Choose Toppings").pack()
        self.topping_vars = {}
        for topping in toppings:
            var = tk.BooleanVar()
            self.topping_vars[topping] = var
            tk.Checkbutton(root, text=topping, variable=var).pack()
        
        tk.Label(root, text="Choose Drink").pack()
        self.drink_var = tk.StringVar()
        for drink in drinks:
            tk.Radiobutton(root, text=drink, variable=self.drink_var, value=drink).pack()
        
        # Buttons
        tk.Button(root, text="Next", command=self.show_summary).pack()
        tk.Button(root, text="Reset", command=self.reset_order).pack()
        tk.Button(root, text="Submit Order", command=self.submit_order).pack()
        tk.Button(root, text="Exit", command=root.quit).pack()
    
    def show_summary(self):
        # Open summary window
        summary_window = tk.Toplevel(self.root)
        summary_window.title("Order Summary")
        order_summary = self.order.generate_summary(self.size_var.get(), self.topping_vars, self.drink_var.get())
        tk.Label(summary_window, text=order_summary).pack()
    
    def reset_order(self):
        self.size_var.set("")
        self.drink_var.set("")
        for var in self.topping_vars.values():
            var.set(False)
    
    def submit_order(self):
        print("Order submitted!")

if __name__ == "__main__":
    root = tk.Tk()
    app = PizzaOrderApp(root)
    root.mainloop()

### order.py
# Handles order processing and price calculations
class Order:
    def __init__(self):
        self.prices = {"Small": 8, "Medium": 10, "Large": 12}
        self.topping_price = 1
        self.drink_price = {"Soda": 2, "Juice": 3, "Water": 1}
    
    def calculate_price(self, size, toppings, drink):
        total = self.prices.get(size, 0)
        total += sum(self.topping_price for t in toppings if toppings[t].get())
        total += self.drink_price.get(drink, 0)
        return total
    
    def generate_summary(self, size, toppings, drink):
        topping_list = [t for t, var in toppings.items() if var.get()]
        total = self.calculate_price(size, toppings, drink)
        return f"Size: {size}\nToppings: {', '.join(topping_list)}\nDrink: {drink}\nTotal: ${total}"

### menu.py
# Stores menu options
pizza_sizes = ["Small", "Medium", "Large"]
toppings = ["Pepperoni", "Mushrooms", "Olives", "Bacon"]
drinks = ["Soda", "Juice", "Water"]

### images.py
# Stores image paths
pizza_image = "pizza.png"
drink_image = "drink.png"

### README.md
# Instructions and documentation for setting up and running the project
# Piz-Out Ordering System
## Setup Instructions
1. Install Python 3.
2. Ensure Tkinter is installed (`pip install tk`).
3. Run `python main.py` to start the application.

## Features
- Select pizza size, toppings, and drinks.
- View order summary before submitting.
- Reset selections and navigate between windows.
- Simple and user-friendly GUI.

## Future Improvements
- Database integration for order history.
- Enhanced UI with better visuals.
- Additional customization options for pizza orders.