"Main.py- Order Now"
import tkinter as tk
from PIL import Image, ImageTk
from order import open_order_window

def main_window():
    root = tk.Tk()
    root.title("Pizza Delivery App")
    root.geometry("500x400")

    # Load an image
    try:
        img = Image.open("image/pizza_triangle.png")  # Ensure correct file extension
        img = img.resize((200, 200))
        pizza_img = ImageTk.PhotoImage(img)
    except Exception as e:
        print(f"Error loading image: {e}")
        pizza_img = None

    # Display image
    if pizza_img:
        label_img = tk.Label(root, image=pizza_img)
        label_img.image = pizza_img  # Prevent garbage collection
        label_img.pack(pady=10)

    # App title
    label = tk.Label(root, text="Welcome to Pizz-Out", font=("Arial", 14, "bold"))
    label.pack(pady=10)

    # Order Button
    order_btn = tk.Button(root, text="Order Now", command=lambda: open_order_window(root))
    order_btn.pack(pady=5)

    # Exit button
    exit_btn = tk.Button(root, text="Exit", command=root.quit)
    exit_btn.pack(pady=5)

    root.mainloop()

if __name__ == "__main__":
    main_window()
